import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { query } from "../db.js";
import { JWT_SECRET } from "../config.js";

const router = Router();

// Simple endpoint to create a first admin (to appeler une fois puis désactiver en prod)
router.post("/seed-admin", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const result = await query(
      "INSERT INTO users_admin (email, password_hash) VALUES ($1,$2) RETURNING id, email",
      [email, hash]
    );
    res.json({ admin: result.rows[0] });
  } catch (e) {
    next(e);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const result = await query("SELECT * FROM users_admin WHERE email = $1", [
      email
    ]);
    const user = result.rows[0];
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: "8h" }
    );
    res.json({ token });
  } catch (e) {
    next(e);
  }
});

export default router;
