import { Router } from "express";
import { query } from "../db.js";

const router = Router();

router.post("/", async (req, res, next) => {
  try {
    const { utm_source, utm_medium, utm_campaign } = req.body;
    const result = await query(
      `INSERT INTO traffic_sources (utm_source, utm_medium, utm_campaign)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [utm_source || null, utm_medium || null, utm_campaign || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (e) {
    next(e);
  }
});

export default router;
