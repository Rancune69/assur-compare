import { Router } from "express";
import { query } from "../db.js";
import { validateLeadPayload } from "../utils/validation.js";
import { authRequired } from "../middleware/auth.js";

const router = Router();

// Création depuis le site public
router.post("/", async (req, res, next) => {
  try {
    const error = validateLeadPayload(req.body);
    if (error) return res.status(400).json({ error });

    const {
      firstName,
      lastName,
      email,
      phone,
      canton,
      productType,
      formData,
      trafficSourceId
    } = req.body;

    const result = await query(
      `INSERT INTO leads
       (first_name, last_name, email, phone, canton, product_type, form_data, traffic_source_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [
        firstName || null,
        lastName || null,
        email || null,
        phone || null,
        canton || null,
        productType,
        formData ? JSON.stringify(formData) : null,
        trafficSourceId || null
      ]
    );
    res.status(201).json(result.rows[0]);
  } catch (e) {
    next(e);
  }
});

// Liste des leads pour l'admin
router.get("/", authRequired, async (req, res, next) => {
  try {
    const {
      productType,
      status,
      canton,
      fromDate,
      toDate,
      limit = 100
    } = req.query;

    let where = [];
    let params = [];
    let idx = 1;

    if (productType) {
      where.push(`product_type = $${idx++}`);
      params.push(productType);
    }
    if (status) {
      where.push(`status = $${idx++}`);
      params.push(status);
    }
    if (canton) {
      where.push(`canton = $${idx++}`);
      params.push(canton);
    }
    if (fromDate) {
      where.push(`created_at >= $${idx++}`);
      params.push(fromDate);
    }
    if (toDate) {
      where.push(`created_at <= $${idx++}`);
      params.push(toDate);
    }

    const whereClause = where.length ? "WHERE " + where.join(" AND ") : "";
    const sql = `
      SELECT * FROM leads
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT $${idx}
    `;
    params.push(limit);

    const result = await query(sql, params);
    res.json(result.rows);
  } catch (e) {
    next(e);
  }
});

// Export CSV simple
router.get("/export", authRequired, async (req, res, next) => {
  try {
    const result = await query(
      "SELECT * FROM leads ORDER BY created_at DESC LIMIT 1000"
    );
    const rows = result.rows;
    if (rows.length === 0) {
      return res.send("id;first_name;last_name;email;phone;canton;product_type;status;created_at");
    }
    const header = Object.keys(rows[0]).join(";");
    const lines = rows.map((r) =>
      Object.values(r)
        .map((v) => (v === null ? "" : String(v).replace(/;/g, ",")))
        .join(";")
    );
    const csv = [header, ...lines].join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="leads_export.csv"'
    );
    res.send(csv);
  } catch (e) {
    next(e);
  }
});

export default router;
