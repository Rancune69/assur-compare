export function validateLeadPayload(body) {
  const required = ["productType"];
  for (const field of required) {
    if (!body[field]) {
      return `Missing field: ${field}`;
    }
  }
  return null;
}
