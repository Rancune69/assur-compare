import dotenv from "dotenv";
dotenv.config();

export const PORT = process.env.PORT || 4000;

export const DB_CONFIG = {
  connectionString:
    process.env.DATABASE_URL ||
    "postgres://assur_user:assur_password@db:5432/assur_compare"
};

export const JWT_SECRET = process.env.JWT_SECRET || "change_me_in_production";
export const CORS_ORIGIN =
  process.env.CORS_ORIGIN || "http://localhost:3000";
