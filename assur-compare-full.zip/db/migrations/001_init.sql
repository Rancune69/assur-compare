CREATE TABLE IF NOT EXISTS users_admin (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS traffic_sources (
  id SERIAL PRIMARY KEY,
  utm_source VARCHAR(255),
  utm_medium VARCHAR(255),
  utm_campaign VARCHAR(255),
  first_visit_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS leads (
  id SERIAL PRIMARY KEY,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  email VARCHAR(255),
  phone VARCHAR(50),
  canton VARCHAR(50),
  product_type VARCHAR(50), -- 'lamal' | 'lca' | 'troisieme_pilier' | 'deuxieme_pilier'
  form_data JSONB,
  traffic_source_id INT REFERENCES traffic_sources(id),
  status VARCHAR(50) DEFAULT 'new', -- 'new' | 'contacted' | 'closed'
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS logs (
  id SERIAL PRIMARY KEY,
  log_type VARCHAR(50),
  message TEXT,
  user_id INT REFERENCES users_admin(id),
  created_at TIMESTAMP DEFAULT NOW()
);
