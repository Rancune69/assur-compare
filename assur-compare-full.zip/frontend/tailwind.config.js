module.exports = {
  content: ["./pages/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#0B7C7C",
        primaryDark: "#065a5a",
        accent: "#F0C14B",
        bg: "#0B1015"
      }
    }
  },
  plugins: []
};
