import MultiStepForm from "../components/MultiStepForm";
import ComparisonTable from "../components/ComparisonTable";

export default function DeuxiemePilierPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-semibold">Optimiser votre 2e pilier (LPP)</h1>
      <p className="text-sm text-white/70 mt-2 max-w-2xl">
        Solutions de prévoyance professionnelle pour indépendants, dirigeants,
        PME et salariés souhaitant améliorer leur couverture.
      </p>
      <div className="grid md:grid-cols-2 gap-8 mt-8">
        <MultiStepForm productType="deuxieme_pilier" />
        <div>
          <ComparisonTable productType="deuxieme_pilier" />
        </div>
      </div>
    </div>
  );
}
