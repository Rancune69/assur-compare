import Link from "next/link";
import MultiStepForm from "../components/MultiStepForm";
import ReassuranceStrip from "../components/ReassuranceStrip";

export default function Home() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <section className="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-3xl md:text-4xl font-semibold leading-tight">
            Comparez vos{" "}
            <span className="text-primary">
              assurances en Suisse
            </span>{" "}
            en quelques minutes.
          </h1>
          <p className="text-sm text-white/70 mt-3">
            LAMal, complémentaires LCA, 3e pilier et 2e pilier. Un seul
            formulaire, des dizaines d’offres triées pour vous, et un expert qui
            vous rappelle gratuitement.
          </p>
          <div className="mt-4 flex flex-wrap gap-2 text-xs text-white/60">
            <span className="px-2 py-1 rounded-full bg-white/5">
              Jusqu’à plusieurs centaines de CHF d’économies
            </span>
            <span className="px-2 py-1 rounded-full bg-white/5">
              Service 100% gratuit & sans engagement
            </span>
          </div>
          <div className="mt-6 flex flex-wrap gap-3 text-sm">
            <Link href="/lamal">
              <button className="px-4 py-2 rounded-md bg-primary hover:bg-primaryDark font-semibold">
                Comparer LAMal
              </button>
            </Link>
            <Link href="/troisieme-pilier">
              <button className="px-4 py-2 rounded-md bg-white/5 border border-white/15">
                Optimiser mon 3e pilier
              </button>
            </Link>
          </div>
        </div>
        <div>
          <MultiStepForm productType="lamal" />
        </div>
      </section>

      <ReassuranceStrip />

      <section className="mt-12 grid md:grid-cols-4 gap-4 text-sm">
        <Link
          href="/lamal"
          className="bg-white/5 hover:bg-white/10 rounded-xl p-4 border border-white/10"
        >
          <h3 className="font-semibold mb-1">Assurance maladie (LAMal)</h3>
          <p className="text-xs text-white/70">
            Comparez les primes, franchises et modèles pour trouver la
            caisse idéale.
          </p>
        </Link>
        <Link
          href="/lca"
          className="bg-white/5 hover:bg-white/10 rounded-xl p-4 border border-white/10"
        >
          <h3 className="font-semibold mb-1">Complémentaires (LCA)</h3>
          <p className="text-xs text-white/70">
            Dentaire, hospitalisation, médecines alternatives, etc.
          </p>
        </Link>
        <Link
          href="/troisieme-pilier"
          className="bg-white/5 hover:bg-white/10 rounded-xl p-4 border border-white/10"
        >
          <h3 className="font-semibold mb-1">3e pilier (3a & 3b)</h3>
          <p className="text-xs text-white/70">
            Optimisez vos impôts et préparez votre retraite.
          </p>
        </Link>
        <Link
          href="/deuxieme-pilier"
          className="bg-white/5 hover:bg-white/10 rounded-xl p-4 border border-white/10"
        >
          <h3 className="font-semibold mb-1">2e pilier (LPP)</h3>
          <p className="text-xs text-white/70">
            Solutions pour indépendants, dirigeants et PME.
          </p>
        </Link>
      </section>
    </div>
  );
}
