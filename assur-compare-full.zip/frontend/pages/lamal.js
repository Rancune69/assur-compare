import MultiStepForm from "../components/MultiStepForm";
import ComparisonTable from "../components/ComparisonTable";

export default function LamalPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-semibold">Comparer votre LAMal</h1>
      <p className="text-sm text-white/70 mt-2 max-w-2xl">
        Comparez les primes, modèles et franchises des principales caisses
        maladie en Suisse. Remplissez quelques informations et recevez des
        offres personnalisées.
      </p>
      <div className="grid md:grid-cols-2 gap-8 mt-8">
        <MultiStepForm productType="lamal" />
        <div>
          <ComparisonTable productType="lamal" />
        </div>
      </div>
    </div>
  );
}
