import MultiStepForm from "../components/MultiStepForm";
import ComparisonTable from "../components/ComparisonTable";

export default function TroisiemePilierPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-semibold">Optimiser votre 3e pilier</h1>
      <p className="text-sm text-white/70 mt-2 max-w-2xl">
        Comparez les solutions 3a et 3b pour optimiser votre fiscalité tout en
        préparant votre retraite et la protection de votre famille.
      </p>
      <div className="grid md:grid-cols-2 gap-8 mt-8">
        <MultiStepForm productType="troisieme_pilier" />
        <div>
          <ComparisonTable productType="troisieme_pilier" />
        </div>
      </div>
    </div>
  );
}
