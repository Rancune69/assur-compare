import { useEffect, useState } from "react";
import api from "../../lib/apiClient";

export default function AdminLeads() {
  const [leads, setLeads] = useState([]);
  const [filters, setFilters] = useState({
    productType: "",
    canton: "",
    status: ""
  });

  function getToken() {
    if (typeof window === "undefined") return null;
    return window.localStorage.getItem("hc_admin_token");
  }

  async function fetchLeads() {
    const token = getToken();
    if (!token) {
      if (typeof window !== "undefined") {
        window.location.href = "/admin/login";
      }
      return;
    }
    const params = {};
    if (filters.productType) params.productType = filters.productType;
    if (filters.canton) params.canton = filters.canton;
    if (filters.status) params.status = filters.status;

    const res = await api.get("/api/leads", {
      params,
      headers: { Authorization: `Bearer ${token}` }
    });
    setLeads(res.data || []);
  }

  useEffect(() => {
    fetchLeads();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Leads</h1>
        <button
          className="px-3 py-1.5 rounded-md bg-white/10 text-xs"
          onClick={fetchLeads}
        >
          Rafraîchir
        </button>
      </div>

      <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6 text-xs flex flex-wrap gap-4">
        <div>
          <label className="block text-white/60 mb-1">Produit</label>
          <select
            className="bg-black/40 border border-white/15 rounded px-2 py-1"
            value={filters.productType}
            onChange={(e) =>
              setFilters((f) => ({ ...f, productType: e.target.value }))
            }
          >
            <option value="">Tous</option>
            <option value="lamal">LAMal</option>
            <option value="lca">LCA</option>
            <option value="troisieme_pilier">3e pilier</option>
            <option value="deuxieme_pilier">2e pilier</option>
          </select>
        </div>
        <div>
          <label className="block text-white/60 mb-1">Canton</label>
          <input
            className="bg-black/40 border border-white/15 rounded px-2 py-1"
            value={filters.canton}
            onChange={(e) =>
              setFilters((f) => ({ ...f, canton: e.target.value }))
            }
          />
        </div>
        <div>
          <label className="block text-white/60 mb-1">Statut</label>
          <input
            className="bg-black/40 border border-white/15 rounded px-2 py-1"
            value={filters.status}
            onChange={(e) =>
              setFilters((f) => ({ ...f, status: e.target.value }))
            }
          />
        </div>
        <button
          className="self-end px-3 py-1.5 rounded-md bg-primary text-xs"
          onClick={fetchLeads}
        >
          Filtrer
        </button>
      </div>

      <div className="overflow-x-auto text-xs">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/10 text-white/60">
              <th className="py-2 pr-3 text-left">Date</th>
              <th className="py-2 pr-3 text-left">Produit</th>
              <th className="py-2 pr-3 text-left">Nom</th>
              <th className="py-2 pr-3 text-left">Email</th>
              <th className="py-2 pr-3 text-left">Téléphone</th>
              <th className="py-2 pr-3 text-left">Canton</th>
              <th className="py-2 pr-3 text-left">Statut</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((l) => (
              <tr key={l.id} className="border-b border-white/5">
                <td className="py-2 pr-3">
                  {l.created_at
                    ? new Date(l.created_at).toLocaleString("fr-CH")
                    : ""}
                </td>
                <td className="py-2 pr-3">{l.product_type}</td>
                <td className="py-2 pr-3">
                  {l.first_name} {l.last_name}
                </td>
                <td className="py-2 pr-3">{l.email}</td>
                <td className="py-2 pr-3">{l.phone}</td>
                <td className="py-2 pr-3">{l.canton}</td>
                <td className="py-2 pr-3">{l.status}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {leads.length === 0 && (
          <p className="text-white/60 mt-4">Aucun lead pour le moment.</p>
        )}
      </div>
    </div>
  );
}
