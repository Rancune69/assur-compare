import { useRouter } from "next/router";
import ComparisonTable from "../../components/ComparisonTable";

export default function ProductResults() {
  const router = useRouter();
  const { product } = router.query;

  if (!product) return null;

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-semibold mb-2">
        Résultats pour {product}
      </h1>
      <p className="text-sm text-white/70 mb-6">
        Voici une sélection d’offres indicatives en fonction de vos réponses.
        Un conseiller vous rappellera pour affiner les détails contractuels.
      </p>
      <ComparisonTable productType={product} />
    </div>
  );
}
