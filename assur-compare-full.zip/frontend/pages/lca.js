import MultiStepForm from "../components/MultiStepForm";
import ComparisonTable from "../components/ComparisonTable";

export default function LcaPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-semibold">Assurances complémentaires (LCA)</h1>
      <p className="text-sm text-white/70 mt-2 max-w-2xl">
        Comparez les couvertures complémentaires : dentaire, hospitalisation,
        médecines alternatives et plus encore, auprès des principaux assureurs.
      </p>
      <div className="grid md:grid-cols-2 gap-8 mt-8">
        <MultiStepForm productType="lca" />
        <div>
          <ComparisonTable productType="lca" />
        </div>
      </div>
    </div>
  );
}
