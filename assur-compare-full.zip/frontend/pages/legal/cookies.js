export default function Cookies() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-10 text-sm text-white/80">
      <h1 className="text-2xl font-semibold mb-4">Cookies</h1>
      <p className="mb-3">
        Nous utilisons des cookies techniques pour le bon fonctionnement du
        site, ainsi que des cookies d’analyse et de mesure d’audience (par
        exemple via Google Analytics ou d’autres outils).
      </p>
      <p className="mb-3">
        Vous pouvez configurer votre navigateur pour bloquer certains types de
        cookies, mais cela peut impacter l’expérience utilisateur. Pour plus
        d’informations, consultez la documentation de votre navigateur.
      </p>
    </div>
  );
}
