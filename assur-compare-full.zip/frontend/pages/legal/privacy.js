export default function Privacy() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-10 text-sm text-white/80">
      <h1 className="text-2xl font-semibold mb-4">
        Politique de confidentialité
      </h1>
      <p className="mb-3">
        Cette politique décrit la manière dont nous collectons, utilisons et
        protégeons vos données personnelles dans le cadre de l’utilisation de
        notre comparateur d’assurances en Suisse.
      </p>
      <p className="mb-3">
        Vous pouvez demander davantage d’informations ou exercer vos droits
        (accès, rectification, suppression) en nous contactant via le formulaire
        de contact ou l’adresse e-mail indiquée dans les mentions légales.
      </p>
    </div>
  );
}
