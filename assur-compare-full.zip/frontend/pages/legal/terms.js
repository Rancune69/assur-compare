export default function Terms() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-10 text-sm text-white/80">
      <h1 className="text-2xl font-semibold mb-4">Mentions légales</h1>
      <p className="mb-3">
        Ce site est un comparateur d’assurances destiné aux résidents suisses.
        Les informations fournies sont indicatives et ne constituent pas une
        offre contractuelle. Les conditions finales sont déterminées directement
        avec les assureurs partenaires.
      </p>
      <p className="mb-3">
        Les coordonnées de l’exploitant du site, ainsi que les informations
        légales complètes, doivent être ajoutées ici (raison sociale, adresse,
        numéro IDE, etc.).
      </p>
    </div>
  );
}
