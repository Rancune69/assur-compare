export default function ComparisonTable({ productType }) {
  // Mock de données — à remplacer plus tard par un appel API vers backend ou un connecteur externe
  const rows = [
    {
      id: 1,
      provider: "HelvetiaCare",
      price: "CHF 290.- / mois",
      satisfaction: "4.7 / 5",
      highlight: "Meilleur rapport qualité/prix"
    },
    {
      id: 2,
      provider: "AlpineSanté",
      price: "CHF 305.- / mois",
      satisfaction: "4.5 / 5",
      highlight: "Couverture hospitalière étendue"
    },
    {
      id: 3,
      provider: "LemanAssur",
      price: "CHF 276.- / mois",
      satisfaction: "4.3 / 5",
      highlight: "Prime la plus basse"
    }
  ];

  return (
    <div className="bg-white/5 rounded-2xl p-6 border border-white/10 mt-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">
          Résultats pour {productType === "lamal" ? "LAMal" : "votre sélection"}
        </h2>
        <p className="text-xs text-white/60">
          Ces offres sont indicatives et seront affinées avec un conseiller.
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-white/60 border-b border-white/10">
              <th className="py-2 pr-4">Assureur</th>
              <th className="py-2 pr-4">Prime estimée</th>
              <th className="py-2 pr-4">Satisfaction</th>
              <th className="py-2 pr-4">Points forts</th>
              <th className="py-2 pr-4"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr
                key={r.id}
                className="border-b border-white/5 last:border-b-0 hover:bg-white/5"
              >
                <td className="py-3 pr-4">{r.provider}</td>
                <td className="py-3 pr-4">{r.price}</td>
                <td className="py-3 pr-4">{r.satisfaction}</td>
                <td className="py-3 pr-4 text-xs text-white/80">
                  {r.highlight}
                </td>
                <td className="py-3 pr-4 text-right">
                  <button className="px-3 py-1.5 text-xs rounded-md bg-primary hover:bg-primaryDark font-semibold">
                    Être rappelé
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
