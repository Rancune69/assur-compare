import { useEffect } from "react";
import Header from "./Header";
import Footer from "./Footer";
import CookieBanner from "./CookieBanner";
import { trackTrafficOnce } from "../lib/tracking";

export default function Layout({ children }) {
  useEffect(() => {
    trackTrafficOnce();
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-bg text-white">
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
      <CookieBanner />
    </div>
  );
}
