import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black/60">
      <div className="max-w-6xl mx-auto px-4 py-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4 text-sm text-white/60">
        <div>© {new Date().getFullYear()} HelvetiCompare. Tous droits réservés.</div>
        <div className="flex gap-4">
          <Link href="/legal/privacy">Politique de confidentialité</Link>
          <Link href="/legal/terms">Mentions légales</Link>
          <Link href="/legal/cookies">Cookies</Link>
        </div>
      </div>
    </footer>
  );
}
