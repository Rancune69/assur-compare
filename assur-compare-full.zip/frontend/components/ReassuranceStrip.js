export default function ReassuranceStrip() {
  return (
    <div className="grid gap-4 md:grid-cols-3 mt-10">
      <div className="bg-white/5 rounded-xl p-4">
        <p className="text-sm font-semibold">+ 20 assureurs partenaires</p>
        <p className="text-xs text-white/70 mt-1">
          Panorama complet des principales caisses et assureurs reconnus en
          Suisse.
        </p>
      </div>
      <div className="bg-white/5 rounded-xl p-4">
        <p className="text-sm font-semibold">Jusqu’à plusieurs centaines de CHF d’économies</p>
        <p className="text-xs text-white/70 mt-1">
          Optimisation des primes et de la couverture en quelques minutes.
        </p>
      </div>
      <div className="bg-white/5 rounded-xl p-4">
        <p className="text-sm font-semibold">Données hébergées en Europe</p>
        <p className="text-xs text-white/70 mt-1">
          Conformité RGPD suisse, chiffrement et stockage sécurisé.
        </p>
      </div>
    </div>
  );
}
