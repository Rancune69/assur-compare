import { useEffect, useState } from "react";

const KEY = "hc_cookie_consent";

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = window.localStorage.getItem(KEY);
    if (!stored) setVisible(true);
  }, []);

  function accept() {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(KEY, "accepted");
    }
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div className="fixed bottom-3 inset-x-0 flex justify-center z-40">
      <div className="max-w-xl mx-4 bg-black/90 border border-white/15 rounded-2xl p-4 text-xs text-white/80 shadow-lg">
        <p>
          Nous utilisons des cookies pour analyser le trafic, améliorer votre
          expérience et mesurer l’efficacité de nos campagnes. Vous pouvez
          gérer vos préférences dans la page Cookies.
        </p>
        <div className="flex justify-end mt-3">
          <button
            className="px-4 py-1.5 rounded-md bg-primary hover:bg-primaryDark text-xs font-semibold"
            onClick={accept}
          >
            J’accepte
          </button>
        </div>
      </div>
    </div>
  );
}
