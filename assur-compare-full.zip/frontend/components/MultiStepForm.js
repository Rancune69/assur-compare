import { useState } from "react";
import axios from "axios";
import ProgressBar from "./ProgressBar";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

export const FORM_CONFIGS = {
  lamal: {
    title: "Comparer votre assurance maladie (LAMal)",
    steps: [
      {
        label: "Profil",
        fields: [
          { name: "canton", label: "Canton", type: "text", required: true },
          { name: "birthYear", label: "Année de naissance", type: "number" }
        ]
      },
      {
        label: "Situation",
        fields: [
          {
            name: "franchise",
            label: "Franchise actuelle",
            type: "select",
            options: ["300", "500", "1000", "1500", "2000", "2500"]
          },
          {
            name: "model",
            label: "Modèle",
            type: "select",
            options: ["Standard", "Médecin de famille", "Telmed", "HMO"]
          }
        ]
      },
      {
        label: "Contact",
        fields: [
          { name: "firstName", label: "Prénom", type: "text", required: true },
          { name: "lastName", label: "Nom", type: "text", required: true },
          { name: "email", label: "Email", type: "email", required: true },
          { name: "phone", label: "Téléphone", type: "tel", required: true }
        ]
      }
    ]
  },
  lca: {
    title: "Comparer vos assurances complémentaires (LCA)",
    steps: [
      {
        label: "Profil",
        fields: [
          { name: "canton", label: "Canton", type: "text", required: true },
          { name: "age", label: "Âge", type: "number" }
        ]
      },
      {
        label: "Besoins",
        fields: [
          {
            name: "coverType",
            label: "Type de couverture",
            type: "select",
            options: ["Hospitalisation", "Dentaire", "Alternative", "Autre"]
          }
        ]
      },
      {
        label: "Contact",
        fields: [
          { name: "firstName", label: "Prénom", type: "text", required: true },
          { name: "lastName", label: "Nom", type: "text", required: true },
          { name: "email", label: "Email", type: "email", required: true },
          { name: "phone", label: "Téléphone", type: "tel", required: true }
        ]
      }
    ]
  },
  troisieme_pilier: {
    title: "Optimiser votre 3e pilier",
    steps: [
      {
        label: "Situation",
        fields: [
          { name: "age", label: "Âge", type: "number" },
          { name: "income", label: "Revenu annuel brut (CHF)", type: "number" }
        ]
      },
      {
        label: "Objectifs",
        fields: [
          {
            name: "goal",
            label: "Objectif principal",
            type: "select",
            options: ["Épargne retraite", "Fiscalité", "Protection famille"]
          }
        ]
      },
      {
        label: "Contact",
        fields: [
          { name: "firstName", label: "Prénom", type: "text", required: true },
          { name: "lastName", label: "Nom", type: "text", required: true },
          { name: "email", label: "Email", type: "email", required: true },
          { name: "phone", label: "Téléphone", type: "tel", required: true }
        ]
      }
    ]
  },
  deuxieme_pilier: {
    title: "Optimiser votre 2e pilier",
    steps: [
      {
        label: "Entreprise / statut",
        fields: [
          { name: "companySize", label: "Taille de l'entreprise", type: "number" },
          { name: "role", label: "Fonction", type: "text" }
        ]
      },
      {
        label: "Prévoyance",
        fields: [
          {
            name: "coverageLevel",
            label: "Niveau actuel de couverture",
            type: "select",
            options: ["Minimum LPP", "Sur-obligatoire", "Inconnu"]
          }
        ]
      },
      {
        label: "Contact",
        fields: [
          { name: "firstName", label: "Prénom", type: "text", required: true },
          { name: "lastName", label: "Nom", type: "text", required: true },
          { name: "email", label: "Email", type: "email", required: true },
          { name: "phone", label: "Téléphone", type: "tel", required: true }
        ]
      }
    ]
  }
};

export default function MultiStepForm({ productType }) {
  const config = FORM_CONFIGS[productType];
  const [step, setStep] = useState(0);
  const [values, setValues] = useState({});
  const [loading, setLoading] = useState(false);
  const [finished, setFinished] = useState(false);
  const [error, setError] = useState("");

  if (!config) return null;

  const currentStep = config.steps[step];

  function updateField(name, value) {
    setValues((v) => ({ ...v, [name]: value }));
  }

  async function handleNext(e) {
    e.preventDefault();
    setError("");

    // Validation minimale
    for (const field of currentStep.fields) {
      if (field.required && !values[field.name]) {
        setError("Merci de compléter tous les champs obligatoires.");
        return;
      }
    }

    if (step < config.steps.length - 1) {
      setStep((s) => s + 1);
    } else {
      // soumission
      setLoading(true);
      try {
        const res = await axios.post(`${API_URL}/api/leads`, {
          productType,
          firstName: values.firstName,
          lastName: values.lastName,
          email: values.email,
          phone: values.phone,
          canton: values.canton,
          formData: values
        });
        if (res.data?.id) {
          setFinished(true);
        }
      } catch (err) {
        setError("Une erreur est survenue. Merci de réessayer.");
      } finally {
        setLoading(false);
      }
    }
  }

  if (finished) {
    return (
      <div className="bg-white/5 rounded-2xl p-6">
        <h3 className="text-lg font-semibold mb-2">
          Merci, votre demande a bien été enregistrée.
        </h3>
        <p className="text-sm text-white/70">
          Un conseiller vous contactera rapidement pour vous présenter les
          meilleures options pour votre situation.
        </p>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleNext}
      className="bg-white/5 rounded-2xl p-6 border border-white/10"
    >
      <h3 className="text-lg font-semibold">{config.title}</h3>
      <p className="text-xs text-white/60 mt-1">
        Quelques questions rapides pour personnaliser votre comparaison.
      </p>

      <ProgressBar step={step + 1} total={config.steps.length} />

      <div className="mt-6 space-y-4">
        {currentStep.fields.map((field) => (
          <div key={field.name} className="flex flex-col gap-1">
            <label className="text-xs text-white/70">
              {field.label} {field.required && <span className="text-red-400">*</span>}
            </label>
            {field.type === "select" ? (
              <select
                className="bg-black/40 border border-white/15 rounded-md px-3 py-2 text-sm"
                value={values[field.name] || ""}
                onChange={(e) => updateField(field.name, e.target.value)}
              >
                <option value="">Sélectionnez...</option>
                {field.options.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            ) : (
              <input
                type={field.type}
                className="bg-black/40 border border-white/15 rounded-md px-3 py-2 text-sm"
                value={values[field.name] || ""}
                onChange={(e) => updateField(field.name, e.target.value)}
              />
            )}
          </div>
        ))}
      </div>

      {error && (
        <p className="text-xs text-red-400 mt-3">
          {error}
        </p>
      )}

      <div className="flex justify-between items-center mt-6">
        <button
          type="button"
          className="text-xs text-white/60 disabled:opacity-30"
          onClick={() => setStep((s) => Math.max(0, s - 1))}
          disabled={step === 0}
        >
          ← Précédent
        </button>
        <button
          type="submit"
          className="px-4 py-2 rounded-md bg-primary hover:bg-primaryDark text-sm font-semibold disabled:opacity-50"
          disabled={loading}
        >
          {step === config.steps.length - 1
            ? loading
              ? "Envoi en cours..."
              : "Voir mes résultats"
            : "Continuer"}
        </button>
      </div>
    </form>
  );
}
