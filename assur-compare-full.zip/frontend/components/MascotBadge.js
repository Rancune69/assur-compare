export default function MascotBadge() {
  return (
    <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center relative overflow-hidden">
      {/* mascotte minimaliste type bouquetin stylisé (placeholder) */}
      <div className="w-5 h-5 border-2 border-white/90 rounded-t-full border-b-0" />
      <div className="absolute -top-1 right-1 w-2 h-3 border-l-2 border-t-2 border-white/80 rounded-sm rotate-12" />
    </div>
  );
}
