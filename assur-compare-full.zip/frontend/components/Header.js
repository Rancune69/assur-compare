import Link from "next/link";
import MascotBadge from "./MascotBadge";

export default function Header() {
  return (
    <header className="border-b border-white/10 bg-black/40 backdrop-blur">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <MascotBadge />
            <div className="flex flex-col">
              <span className="font-semibold tracking-wide">
                HelvetiCompare
              </span>
              <span className="text-xs text-white/60">
                Excellence & confiance
              </span>
            </div>
          </div>
        </Link>
        <nav className="flex items-center gap-6 text-sm">
          <Link href="/lamal">LAMal</Link>
          <Link href="/lca">Complémentaires</Link>
          <Link href="/troisieme-pilier">3e pilier</Link>
          <Link href="/deuxieme-pilier">2e pilier</Link>
        </nav>
      </div>
    </header>
  );
}
