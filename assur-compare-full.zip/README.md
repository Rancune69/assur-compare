# HelvetiCompare – Comparateur d'assurances Suisse

Projet monorepo : frontend (Next.js + Tailwind) + backend (Node/Express) + PostgreSQL.

## Architecture

- `frontend/` : application Next.js (SSR) pour la partie publique et le dashboard admin.
- `backend/` : API REST Node/Express (leads, auth admin, tracking UTM).
- `db/` : migrations SQL pour PostgreSQL.
- `docker-compose.yml` : orchestration des services.

## Installation locale (sans Docker)

### 1. Base de données

Créer une base PostgreSQL `assur_compare` et exécuter la migration :

```bash
psql -U assur_user -d assur_compare -f db/migrations/001_init.sql
```

### 2. Backend

```bash
cd backend
cp .env.example .env
# Éditer la connexion DB + JWT_SECRET
npm install
npm run dev
```

L'API écoute par défaut sur `http://localhost:4000`.

### 3. Frontend

```bash
cd frontend
npm install
npm run dev
```

Le site est accessible sur `http://localhost:3000`.

Définir dans `frontend/.env.local` :

```env
NEXT_PUBLIC_API_URL=http://localhost:4000
```

## Variables d'environnement backend

```env
PORT=4000
DATABASE_URL=postgres://assur_user:assur_password@db:5432/assur_compare
JWT_SECRET=une_chaine_secrete
CORS_ORIGIN=http://localhost:3000
```

## Docker

```bash
docker-compose up --build
```

- Frontend : http://localhost:3000
- Backend : http://localhost:4000
- DB : port 5432

## Fonctionnalités incluses

- Formulaires multi-étapes LAMal, LCA, 3e pilier, 2e pilier.
- Création de leads en base avec tracking UTM (endpoint `/api/traffic`).
- Tableau de résultats comparatifs (mock).
- Dashboard admin sécurisé (login + liste des leads + export CSV).
- SEO de base (meta, H1/H2, GTM placeholder, possibilité d'ajouter sitemap/robots).
- Bandeau cookies, pages légales.

## Améliorations possibles

- Connexion à un vrai moteur de comparaison ou API partenaire.
- Ajout de tests unitaires et e2e.
- Internationalisation (FR/DE/IT).
- A/B tests sur les CTA et wording.
